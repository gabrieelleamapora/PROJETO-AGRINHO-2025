// Variáveis para as imagens (você precisará carregar suas próprias imagens)
let imgCampo;
let imgCidade;
let imgBateria;
let imgOleo;
let imgAgrotoxico;
let imgCaminhaoColeta;
let imgCentroReciclagemPlastico;
let imgCentroReciclagemOleo;
let imgCentroReciclagemBateria;

// Variáveis para os objetos de resíduos
let baterias = [];
let oleos = [];
let agrotoxicos = [];
let todosResiduos = []; // Para facilitar a iteração de todos os resíduos
let itensNoCaminhao = []; // Itens que foram coletados e estão "no caminhão"

// Variáveis para controle de arrasto
let arrastandoObjeto = null; // Guarda o objeto que está sendo arrastado
let offsetX, offsetY;      // Guarda o offset do mouse ao clicar no objeto

// Estado do jogo
let estadoJogo = 'campo'; // 'campo', 'coletando', 'transporte', 'cidade'

// Definição das áreas interativas
let areaColeta;
let areaPlastico;
let areaOleo;
let areaBateria;

function preload() {
  // Carregue suas imagens aqui.
  // Certifique-se de que os caminhos para as imagens estão corretos.
  // Exemplo:
  // imgCampo = loadImage('assets/campo.png');
  // imgCidade = loadImage('assets/cidade.png');
  // imgBateria = loadImage('assets/bateria.png');
  // imgOleo = loadImage('assets/oleo.png');
  // imgAgrotoxico = loadImage('assets/agrotoxico.png');
  // imgCaminhaoColeta = loadImage('assets/caminhao.png');
  // imgCentroReciclagemPlastico = loadImage('assets/reciclagem_plastico.png');
  // imgCentroReciclagemOleo = loadImage('assets/reciclagem_oleo.png');
  // imgCentroReciclagemBateria = loadImage('assets/reciclagem_bateria.png');

  // Deixando o preload vazio por enquanto para o código rodar sem erros de imagem.
}

function setup() {
  createCanvas(900, 600); // Um bom tamanho para dividir campo e cidade

  // Define as coordenadas das áreas interativas
  areaColeta = { x: width / 2 - 100, y: height / 2 - 50, w: 200, h: 100 };
  areaPlastico = { x: width * 0.6, y: height * 0.2, w: 120, h: 120 };
  areaOleo = { x: width * 0.75, y: height * 0.5, w: 120, h: 120 };
  areaBateria = { x: width * 0.6, y: height * 0.8, w: 120, h: 120 };

  // Crie alguns resíduos iniciais no campo
  for (let i = 0; i < 2; i++) { // Diminuí a quantidade para facilitar o teste
    let b = new Residuo(random(50, width / 2 - 50), random(100, height - 100), 'bateria');
    let o = new Residuo(random(50, width / 2 - 50), random(100, height - 100), 'oleo');
    let a = new Residuo(random(50, width / 2 - 50), random(100, height - 100), 'agrotoxico');
    
    baterias.push(b);
    oleos.push(o);
    agrotoxicos.push(a);
    
    todosResiduos.push(b, o, a); // Adiciona a lista geral
  }
}

function draw() {
  background(220);

  // Desenha o fundo (campo e cidade)
  desenharCenario();

  // Desenha os resíduos no campo (se não foram coletados)
  for (let r of todosResiduos) {
    if (!r.isCollected && !r.isRecycled) {
      r.display();
    }
  }

  // Desenha os pontos de coleta e reciclagem
  desenharPontosInterativos();

  // Desenha os itens no caminhão
  desenharItensNoCaminhao();

  // Exibe a mensagem de oportunidades
  exibirMensagensOportunidades();
}

function mousePressed() {
  // Itera sobre todos os resíduos para ver qual foi clicado
  for (let i = todosResiduos.length - 1; i >= 0; i--) {
    let r = todosResiduos[i];
    if (!r.isCollected && !r.isRecycled && r.isOver()) {
      arrastandoObjeto = r;
      offsetX = mouseX - arrastandoObjeto.x;
      offsetY = mouseY - arrastandoObjeto.y;
      return; // Sai da função para arrastar apenas um objeto por vez
    }
  }
}

function mouseDragged() {
  if (arrastandoObjeto != null) {
    arrastandoObjeto.x = mouseX - offsetX;
    arrastandoObjeto.y = mouseY - offsetY;
  }
}

function mouseReleased() {
  if (arrastandoObjeto != null) {
    // Verifica se o objeto foi solto no ponto de coleta
    if (!arrastandoObjeto.isCollected && colisao(arrastandoObjeto, areaColeta)) {
      arrastandoObjeto.isCollected = true;
      itensNoCaminhao.push(arrastandoObjeto);
      // Coloca o objeto em uma posição visual dentro da área do caminhão/coleta
      // Para simular que ele foi "coletado"
      arrastandoObjeto.x = areaColeta.x + areaColeta.w / 2 - arrastandoObjeto.size / 2;
      arrastandoObjeto.y = areaColeta.y + areaColeta.h / 2 - arrastandoObjeto.size / 2;
    }
    
    // Verifica se o objeto foi solto em um centro de reciclagem (apenas se já foi coletado)
    if (arrastandoObjeto.isCollected) {
      verificarReciclagem(arrastandoObjeto);
    }
    
    arrastandoObjeto = null;
  }
}

function desenharCenario() {
  // Lado esquerdo: Campo
  fill(150, 200, 100); // Verde claro para o campo
  rect(0, 0, width / 2, height);
  // if (imgCampo) image(imgCampo, 0, 0, width / 2, height); // Se você tiver a imagem

  // Lado direito: Cidade
  fill(180, 180, 180); // Cinza para a cidade
  rect(width / 2, 0, width / 2, height);
  // if (imgCidade) image(imgCidade, width / 2, 0, width / 2, height); // Se você tiver a imagem

  // Linha divisória
  stroke(100);
  line(width / 2, 0, width / 2, height);
}

function desenharPontosInterativos() {
  // Ponto de Coleta no Campo (caminhão ou container)
  fill(100, 100, 250, 150); // Azul semi-transparente
  rect(areaColeta.x, areaColeta.y, areaColeta.w, areaColeta.h);
  // if (imgCaminhaoColeta) image(imgCaminhaoColeta, areaColeta.x, areaColeta.y, areaColeta.w, areaColeta.h);
  fill(0);
  textSize(14);
  textAlign(CENTER, CENTER);
  text("Ponto de Coleta", areaColeta.x + areaColeta.w / 2, areaColeta.y + areaColeta.h / 2);

  // Centros de Reciclagem na Cidade
  // Centro de Reciclagem de Plástico
  fill(255, 100, 100, 150); // Vermelho semi-transparente
  rect(areaPlastico.x, areaPlastico.y, areaPlastico.w, areaPlastico.h);
  // if (imgCentroReciclagemPlastico) image(imgCentroReciclagemPlastico, areaPlastico.x, areaPlastico.y, areaPlastico.w, areaPlastico.h);
  fill(0);
  text("Reciclagem Plástico", areaPlastico.x + areaPlastico.w / 2, areaPlastico.y + areaPlastico.h / 2);

  // Centro de Reciclagem de Óleo
  fill(100, 255, 100, 150); // Verde semi-transparente
  rect(areaOleo.x, areaOleo.y, areaOleo.w, areaOleo.h);
  // if (imgCentroReciclagemOleo) image(imgCentroReciclagemOleo, areaOleo.x, areaOleo.y, areaOleo.w, areaOleo.h);
  fill(0);
  text("Reciclagem Óleo", areaOleo.x + areaOleo.w / 2, areaOleo.y + areaOleo.h / 2);

  // Centro de Reciclagem de Bateria
  fill(100, 100, 255, 150); // Azul semi-transparente
  rect(areaBateria.x, areaBateria.y, areaBateria.w, areaBateria.h);
  // if (imgCentroReciclagemBateria) image(imgCentroReciclagemBateria, areaBateria.x, areaBateria.y, areaBateria.w, areaBateria.h);
  fill(0);
  text("Reciclagem Bateria", areaBateria.x + areaBateria.w / 2, areaBateria.y + areaBateria.h / 2);
}

function desenharItensNoCaminhao() {
  // Desenha os itens que foram coletados e estão "no caminhão"
  // Aqui você pode criar uma representação visual do caminhão com os itens dentro
  // Por simplicidade, eles apenas ficam visíveis na área do caminhão
  for (let item of itensNoCaminhao) {
    if (!item.isRecycled) { // Desenha apenas se não foi reciclado ainda
      item.display();
    }
  }
}

// Variáveis para as mensagens de oportunidades
let mensagemOportunidade = "";
let tempoMensagem = 0;

function exibirMensagensOportunidades() {
  if (mensagemOportunidade !== "" && millis() - tempoMensagem < 3000) { // Exibe por 3 segundos
    fill(0, 150); // Fundo escuro semi-transparente para o texto
    rect(width / 2 - 200, height - 80, 400, 60, 10);
    fill(255); // Texto branco
    textSize(18);
    textAlign(CENTER, CENTER);
    text(mensagemOportunidade, width / 2, height - 50);
  }
}

function verificarReciclagem(objeto) {
  // Somente verifica a reciclagem se o objeto já foi coletado
  if (objeto.isCollected) {
    // Centro de Reciclagem de Plástico (para agrotoxico)
    if (objeto.tipo === 'agrotoxico' && colisao(objeto, areaPlastico)) {
      objeto.isRecycled = true;
      mensagemOportunidade = "Plástico reciclado: Novos produtos e empregos!";
      tempoMensagem = millis();
      removerResiduoDoCaminhao(objeto);
    }
    // Centro de Reciclagem de Óleo
    else if (objeto.tipo === 'oleo' && colisao(objeto, areaOleo)) {
      objeto.isRecycled = true;
      mensagemOportunidade = "Óleo transformado: Energia limpa e renda!";
      tempoMensagem = millis();
      removerResiduoDoCaminhao(objeto);
    }
    // Centro de Reciclagem de Bateria
    else if (objeto.tipo === 'bateria' && colisao(objeto, areaBateria)) {
      objeto.isRecycled = true;
      mensagemOportunidade = "Bateria reaproveitada: Tecnologia sustentável e prevenção de contaminação!";
      tempoMensagem = millis();
      removerResiduoDoCaminhao(objeto);
    } else {
      // Se soltar em um local errado ou em nenhuma área de reciclagem específica
      // O objeto volta para a posição original de coleta (ou onde foi solto)
      // Para simplificar, ele apenas para de ser arrastado.
      // Você pode adicionar uma lógica para "devolver" o item ao caminhão visualmente.
    }
  }
}

function removerResiduoDoCaminhao(objeto) {
    itensNoCaminhao = itensNoCaminhao.filter(item => item !== objeto);
    // Remove também da lista geral para não ser mais desenhado
    todosResiduos = todosResiduos.filter(item => item !== objeto);
}

// Função auxiliar para verificar colisão entre um objeto (com x, y, size) e uma área (com x, y, w, h)
function colisao(objeto, area) {
  return objeto.x < area.x + area.w &&
         objeto.x + objeto.size > area.x &&
         objeto.y < area.y + area.h &&
         objeto.y + objeto.size > area.y;
}


// Classe para representar os resíduos
class Residuo {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.size = 40; // Tamanho do ícone
    this.tipo = tipo; // 'bateria', 'oleo', 'agrotoxico'
    this.isCollected = false; // Indica se o resíduo foi coletado
    this.isRecycled = false; // Indica se o resíduo foi reciclado
  }

  display() {
    // Desenha o resíduo. Você pode substituir por imagens.
    push(); // Salva o estado atual das configurações de desenho
    rectMode(CORNER); // Para que o rect desenhe a partir do canto superior esquerdo
    textAlign(CENTER, CENTER);
    textSize(10);
    fill(255); // Cor do texto

    if (this.tipo === 'bateria') {
      fill(50, 50, 50); // Cinza escuro
      // if (imgBateria) image(imgBateria, this.x, this.y, this.size, this.size);
      rect(this.x, this.y, this.size, this.size);
      text("BAT", this.x + this.size / 2, this.y + this.size / 2);
    } else if (this.tipo === 'oleo') {
      fill(150, 100, 0); // Marrom escuro
      // if (imgOleo) image(imgOleo, this.x, this.y, this.size, this.size);
      ellipse(this.x + this.size / 2, this.y + this.size / 2, this.size, this.size);
      text("ÓLEO", this.x + this.size / 2, this.y + this.size / 2);
    } else if (this.tipo === 'agrotoxico') {
      fill(0, 150, 0); // Verde escuro
      // if (imgAgrotoxico) image(imgAgrotoxico, this.x, this.y, this.size, this.size);
      triangle(this.x, this.y + this.size, this.x + this.size / 2, this.y, this.x + this.size, this.y + this.size);
      text("AGRO", this.x + this.size / 2, this.y + this.size / 2);
    }
    pop(); // Restaura o estado anterior das configurações de desenho
  }

  isOver() {
    // Verifica se o mouse está sobre o objeto
    return mouseX > this.x && mouseX < this.x + this.size &&
           mouseY > this.y && mouseY < this.y + this.size;
  }
}